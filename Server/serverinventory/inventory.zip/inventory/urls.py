from django.urls import path
from .views import CategoryListCreateView,ProductListCreateView,CreateInvoiceView,InvoiceDetailView,ProductListView,MarkInvoiceDeliveredView,InvoiceListView,ShopInvoiceListView,BrandListCreateView,ShopListCreateView,ProductRetrieveUpdateView,UpdateOrderItemView,RemoveOrderItemView,ProductDestroyView,BrandRetrieveUpdateDestroyView,ShopRetrieveUpdateDestroyView,CategoryRetrieveUpdateDestroyView,DeliveredInvoiceDeleteView, DeliveredInvoiceListView
urlpatterns = [
  path('categories/', CategoryListCreateView.as_view(), name='add-category'), 
  path('categories/<int:id>/', CategoryRetrieveUpdateDestroyView.as_view(), name='update-delete-category'),
  path('brand/', BrandListCreateView.as_view(), name='add-brand'),
  path('brand/<int:pk>/', BrandRetrieveUpdateDestroyView.as_view(), name='brand-detail'),
  path('product/', ProductListCreateView.as_view(), name='products'), 
  path("product/", ProductListView.as_view(), name="product-list"),
  path('product/<int:id>/', ProductRetrieveUpdateView.as_view(), name='product-update'),
  path('product/<int:id>/delete/', ProductDestroyView.as_view(), name='product-delete'),
  path("shops/", ShopListCreateView.as_view(), name="shop-list"),
  path("shops/<int:id>/", ShopRetrieveUpdateDestroyView.as_view(), name="shop-detail"),
  path("invoice/create/", CreateInvoiceView.as_view(), name="invoice-create"),
  path("invoices/<int:pk>/", InvoiceDetailView.as_view(), name="invoice-detail"),
  path('invoices/<int:pk>/deliver/', MarkInvoiceDeliveredView.as_view(),name='invoice-deliver'),
  path('invoices/', InvoiceListView.as_view(), name='invoice-list'),
  path('shops/<int:shop_id>/invoices/', ShopInvoiceListView.as_view(), name='shop-invoices'),
  path('order-items/<int:pk>/update/', UpdateOrderItemView.as_view(), name='update-order-item'),
path("order-items/<int:id>/remove/", RemoveOrderItemView.as_view(), name="remove-item"),
path('invoices/delivered/', DeliveredInvoiceListView.as_view(), name='delivered-invoices'),
    path('invoices/delivered/<int:pk>/', DeliveredInvoiceDeleteView.as_view(), name='delete-delivered-invoice'),
  
]
